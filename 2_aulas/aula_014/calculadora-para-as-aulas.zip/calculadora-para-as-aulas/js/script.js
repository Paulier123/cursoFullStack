const n1Input = document.querySelector("#n1");
const n2Input = document.querySelector("#n2");
const result = document.querySelector(".result-caixa p");
const operador = document.querySelector(".operador p");

const getN1 = () => Number(n1Input.value);
const getN2 = () => Number(n2Input.value);


